extends Node

signal data_updated()
signal save_loaded()

var _save_data: Dictionary = {}

const SAVE_FILE_PATH := "user://mecha_save.json"
const CURRENT_VERSION := 1

func _ready() -> void:
	load_game()

func load_game() -> void:
	if not FileAccess.file_exists(SAVE_FILE_PATH):
		_create_new_save()
		return
	
	var file := FileAccess.open(SAVE_FILE_PATH, FileAccess.READ)
	if file:
		var content := file.get_as_text()
		file.close()
		var parsed: Variant = JSON.parse_string(content)
		if parsed is Dictionary:
			_save_data = _migrate(parsed)
		else:
			push_warning("Corrupt save file, using default")
			_create_new_save()
	else:
		_create_new_save()
	
	save_loaded.emit()

func _create_new_save() -> void:
	_save_data = {
		"version": CURRENT_VERSION,
		"meta": {
			"created_at": Time.get_unix_time_from_system(),
			"last_login": Time.get_unix_time_from_system()
		},
		"progression": {
			"current_stage": 1,
			"highest_stage": 1,
			"total_battles": 0,
			"victories": 0
		},
		"economy": {
			"tech_credits": 0,
			"premium_currency": 0
		},
		"mechas": {
			"unlocked_mecha_ids": ["mecha_unit_alpha_base"],
			"active_mecha_id": "mecha_unit_alpha_base"
		},
		"upgrades": {
			"ballistic_core": {
				"chassis_calibrator_level": 0,
				"multi_shot_loader_level": 0
			},
			"energy_matrix": {
				"processor_overclock_level": 0,
				"payload_expansion_level": 0
			},
			"tactician_protocol": {
				"piercing_barrel_level": 0,
				"emp_grid_level": 0
			}
		},
		"settings": {
			"sound": true,
			"haptics": true,
			"sfx_volume": 1.0,
			"music_volume": 1.0
		}
	}
	save_game()

func _migrate(old_data: Dictionary) -> Dictionary:
	var version = old_data.get("version", 0)
	
	if version < CURRENT_VERSION:
		push_warning("Save file version %d, migrating to %d" % [version, CURRENT_VERSION])
		# Add migration logic here as versions increase
	
	old_data["version"] = CURRENT_VERSION
	return old_data

func save_game() -> void:
	_save_data["meta"]["last_login"] = Time.get_unix_time_from_system()
	
	# Safe file write with atomic rename (AGENTS.md 2.3)
	var tmp_path := SAVE_FILE_PATH + ".tmp"
	var file := FileAccess.open(tmp_path, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(_save_data, "  "))
		file.close()
		
		var abs_save_path := ProjectSettings.globalize_path(SAVE_FILE_PATH)
		var abs_tmp_path := ProjectSettings.globalize_path(tmp_path)
		var dir := DirAccess.open("user://")
		if dir:
			if FileAccess.file_exists(SAVE_FILE_PATH):
				dir.remove_absolute(abs_save_path)
			dir.rename_absolute(abs_tmp_path, abs_save_path)
		
		data_updated.emit()
	else:
		push_error("Failed to write save file")

func get_data() -> Dictionary:
	return _save_data.duplicate()

func add_tech_credits(amount: int) -> void:
	if amount <= 0:
		push_warning("add_tech_credits: invalid amount %d" % amount)
		return
	_save_data["economy"]["tech_credits"] += amount
	save_game()

func spend_tech_credits(amount: int) -> bool:
	if _save_data["economy"]["tech_credits"] < amount:
		return false
	_save_data["economy"]["tech_credits"] -= amount
	save_game()
	return true

func get_tech_credits() -> int:
	return _save_data["economy"]["tech_credits"]

func set_current_stage(stage: int) -> void:
	_save_data["progression"]["current_stage"] = stage
	if stage > _save_data["progression"]["highest_stage"]:
		_save_data["progression"]["highest_stage"] = stage
	save_game()

func get_current_stage() -> int:
	return _save_data["progression"]["current_stage"]

func get_highest_stage() -> int:
	return _save_data["progression"]["highest_stage"]

func unlock_mecha(mecha_id: String) -> void:
	if not mecha_id in _save_data["mechas"]["unlocked_mecha_ids"]:
		_save_data["mechas"]["unlocked_mecha_ids"].append(mecha_id)
		save_game()

func set_active_mecha(mecha_id: String) -> void:
	if mecha_id in _save_data["mechas"]["unlocked_mecha_ids"]:
		_save_data["mechas"]["active_mecha_id"] = mecha_id
		save_game()

func get_active_mecha() -> String:
	return _save_data["mechas"]["active_mecha_id"]

func get_unlocked_mechas() -> Array[String]:
	return _save_data["mechas"]["unlocked_mecha_ids"]

func set_upgrade_level(module: String, upgrade: String, level: int) -> void:
	if _save_data["upgrades"].has(module) and _save_data["upgrades"][module].has(upgrade):
		_save_data["upgrades"][module][upgrade] = level
		save_game()

func get_upgrade_level(module: String, upgrade: String) -> int:
	if _save_data["upgrades"].has(module) and _save_data["upgrades"][module].has(upgrade):
		return _save_data["upgrades"][module][upgrade]
	return 0

func get_setting(key: String) -> Variant:
	return _save_data.get("settings", {}).get(key, null)

func set_setting(key: String, value: Variant) -> void:
	_save_data["settings"][key] = value
	save_game()

func reset_save() -> void:
	_create_new_save()
