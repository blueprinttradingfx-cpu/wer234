extends Node2D
class_name WeaponSystem

# --- SIGNALS ---
signal enemy_shot_fired(projectile_data: Dictionary)

# --- CONSTANTS ---
const BASE_ENEMY_HP := 10.0

# --- CONFIGURATION REFERENCES (Injected by BattleManager) ---
var base_damage: float = 10.0
var attack_speed: float = 2.5 # Attacks per second

# --- MULTI-SHOT UPGRADE STATE ---
# Level 0: Pure Single Shot
# Level 1: [Single] -> [Single] -> [Dual]
# Level 2: [Single] -> [Dual] -> [Triple]
var multi_shot_level: int = 0 

# --- INTERNAL CORE AUTOMATION STATE ---
var shot_sequence_index: int = 0
@onready var fire_timer: Timer = $FireTimer

func _ready() -> void:
	setup_fire_timer()

func setup_fire_timer() -> void:
	if fire_timer:
		fire_timer.timeout.connect(_on_fire_timer_timeout)
		update_weapon_speed()
	else:
		push_error("[WeaponSystem] FireTimer not found")

## Call this whenever attack speed upgrades are purchased or applied
func update_weapon_speed() -> void:
	if fire_timer:
		if attack_speed > 0:
			fire_timer.wait_time = 1.0 / attack_speed
			fire_timer.start()
		else:
			fire_timer.stop()

func _on_fire_timer_timeout() -> void:
	var target_enemies = acquire_targets()
	if target_enemies.is_empty():
		return # Idle state: No enemies within screen boundaries
		
	execute_firing_sequence(target_enemies)

## Scans the screen context to return valid targets sorted by closest distance
func acquire_targets() -> Array[Node2D]:
	var targets: Array[Node2D] = []
	var live_enemies = get_tree().get_nodes_in_group("enemies")
	
	# Early exit if the screen board is completely clear
	if live_enemies.is_empty():
		return targets
		
	# Sort enemies radially by proximity to the center mecha positioning
	live_enemies.sort_custom(func(a, b): 
		return global_position.distance_to(a.global_position) < global_position.distance_to(b.global_position)
	)
	
	for enemy in live_enemies:
		if is_instance_valid(enemy):
			targets.append(enemy)
	return targets

## Evaluates the strict sequential cadence rules based on Upgrade Level
func execute_firing_sequence(available_targets: Array[Node2D]) -> void:
	var bullet_count: int = 1 # Default Level 0 Baseline
	
	match multi_shot_level:
		1:
			# Sequence rhythm: Single (0) -> Single (1) -> Dual (2)
			if shot_sequence_index == 2:
				bullet_count = 2
			else:
				bullet_count = 1
			shot_sequence_index = (shot_sequence_index + 1) % 3
			
		2:
			# Sequence rhythm: Single (0) -> Dual (1) -> Triple (2)
			if shot_sequence_index == 1:
				bullet_count = 2
			elif shot_sequence_index == 2:
				bullet_count = 3
			else:
				bullet_count = 1
			shot_sequence_index = (shot_sequence_index + 1) % 3
			
		_:
			# Level 0 default behavior: Flat loop, no indexing calculation needed
			bullet_count = 1
			
	# Deploy the calculated bullet array into target entities
	deploy_projectiles(bullet_count, available_targets)

## Distributes shots across distinct targets to resolve local crowd density
func deploy_projectiles(count: int, targets: Array[Node2D]) -> void:
	for i in range(count):
		# If density is lower than weapon capability, dump remaining payload into the primary target
		var target = targets[i] if i < targets.size() else targets[0]
		
		if is_instance_valid(target):
			# Because hit rate is 100%, we execute damage immediately
			# (Pierce / EMP logic can hook directly into the targeted enemy context here)
			if target.has_method("take_damage"):
				target.take_damage(base_damage)
				
			# Emit tracking payload for visual sprite/laser instancing components
			enemy_shot_fired.emit({
				"target_position": target.global_position,
				"damage": base_damage,
				"bullet_index": i
			})

## Set multi-shot level from upgrades
func set_multi_shot_level(level: int) -> void:
	multi_shot_level = clamp(level, 0, 2)
	shot_sequence_index = 0 # Reset sequence on level change

## Update base damage from upgrades
func set_base_damage(damage: float) -> void:
	base_damage = damage

## Update attack speed from upgrades
func set_attack_speed(speed: float) -> void:
	attack_speed = speed
	update_weapon_speed()
