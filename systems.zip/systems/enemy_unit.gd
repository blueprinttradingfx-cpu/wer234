extends CharacterBody2D
class_name EnemyUnit

# --- SIGNALS ---
signal destroyed()

# --- VARIABLES ---
@export var max_hp: float = 10.0
var current_hp: float = 10.0

@export var speed_modifier: float = 1.0
var is_boss: bool = false
var archetype: String = "normal"

var battle_manager = null

func _ready() -> void:
	add_to_group("enemies")
	current_hp = max_hp
	battle_manager = get_node_or_null("/root/BattleManager")

func set_speed_modifier(modifier: float) -> void:
	speed_modifier = modifier

func take_damage(amount: float) -> void:
	current_hp -= amount
	if current_hp <= 0:
		execute_destruction()

func execute_destruction() -> void:
	# Handshake validation to prevent dual-frame reporting errors
	remove_from_group("enemies")
	
	if battle_manager and battle_manager.has_method("register_enemy_destruction"):
		battle_manager.register_enemy_destruction()
	
	destroyed.emit()
	
	# Trigger local explosion visual systems here before freeing memory
	queue_free()
