extends Node

# --- SIGNALS ---
signal battle_state_changed(new_state: BattleState)
signal wave_changed(wave: int)
signal enemy_count_changed(count: int)
signal stage_time_changed(time_remaining: float)
signal battle_victory()
signal battle_defeat(reason: String)

# --- ENUMS ---
enum BattleState {
	IDLE,
	ACTIVE,
	PAUSED,
	DEFEATED,
	VICTORY
}

# --- VARIABLES ---
var current_stage_config: Dictionary = {}
var current_wave: int = 1
var alive_enemy_count: int = 0
var stage_time_remaining: float = 300.0
var battle_state: BattleState = BattleState.IDLE
var max_heart_limit: int = 50

@export var current_wave_enemy_scene: PackedScene

# --- INTERNAL ---
var _stage_timer: Timer
var _spawn_timer: Timer

func _ready() -> void:
	_setup_timers()

func _setup_timers() -> void:
	_stage_timer = Timer.new()
	_stage_timer.wait_time = 1.0
	_stage_timer.timeout.connect(_on_stage_timer_timeout)
	add_child(_stage_timer)
	
	_spawn_timer = Timer.new()
	_spawn_timer.timeout.connect(_on_spawn_timer_timeout)
	add_child(_spawn_timer)

## Initialize battle for a specific stage
func start_battle(stage_id: int) -> void:
	current_wave = 1
	alive_enemy_count = 0
	stage_time_remaining = 300.0
	
	# Query the Singleton for the current layer's stat profile
	var progression = get_node_or_null("/root/ProgressionManager")
	if progression:
		current_stage_config = progression.get_config_for_stage(stage_id)
		
		# Hook active mecha configuration data down to weapon component
		var mecha_profile = progression.get_active_mecha_stats()
		if not mecha_profile.is_empty():
			# These will be connected to actual weapon system nodes when scenes are set up
			print("Mecha profile loaded: ", mecha_profile["name"])
	
	_set_battle_state(BattleState.ACTIVE)
	_stage_timer.start()
	_start_spawn_loop()

func _start_spawn_loop() -> void:
	if current_stage_config.is_empty():
		return
	
	var spawn_interval: float = current_stage_config.get("spawn_interval", 0.4)
	if spawn_interval > 0:
		_spawn_timer.wait_time = spawn_interval
		_spawn_timer.start()

func _on_spawn_timer_timeout() -> void:
	if battle_state != BattleState.ACTIVE:
		return
	
	spawn_enemy_entity()

## Spawn enemy with stage-configured stats
func spawn_enemy_entity() -> void:
	if current_wave_enemy_scene == null:
		push_warning("BattleManager: No enemy scene assigned")
		return
	
	# Group spawn count support (1-3 per tick)
	var group_spawn_count: int = current_stage_config.get("group_spawn_count", 1)
	
	for i in range(group_spawn_count):
		if alive_enemy_count >= max_heart_limit:
			break
		
		var enemy_instance = current_wave_enemy_scene.instantiate()
		
		# Pass the cycle-multiplied HP down to the newly created entity instance
		enemy_instance.max_hp = current_stage_config.get("enemy_hp", 10.0)
		
		# Pass velocity modifiers directly to the path-following components
		if enemy_instance.has_method("set_speed_modifier"):
			enemy_instance.set_speed_modifier(current_stage_config.get("velocity_modifier", 1.0))
		
		# Set spawn position at boundary
		enemy_instance.global_position = _get_spawn_position()
		
		# Check if this is a boss wave (wave 100)
		if current_wave >= 100:
			enemy_instance.is_boss = true
			enemy_instance.max_hp = current_stage_config.get("boss_hp", 290.0)
			enemy_instance.scale = Vector2(2.0, 2.0) # Make boss larger
		
		# Connect to destruction tracking
		if enemy_instance.has_signal("destroyed"):
			enemy_instance.destroyed.connect(_on_enemy_destroyed)
		
		add_child(enemy_instance)
		alive_enemy_count += 1
		enemy_count_changed.emit(alive_enemy_count)
	
	# Check heart limit
	if alive_enemy_count >= max_heart_limit:
		_handle_defeat("Heart limit exceeded")

## Get spawn position at boundary
func _get_spawn_position() -> Vector2:
	var viewport = get_viewport()
	var viewport_size = viewport.get_visible_rect().size
	
	# Spawn at top edge, random x position
	var spawn_x = randf_range(50.0, viewport_size.x - 50.0)
	return Vector2(spawn_x, -50.0)

func _on_enemy_destroyed() -> void:
	alive_enemy_count -= 1
	enemy_count_changed.emit(alive_enemy_count)
	
	# Advance wave based on data skip multiplier
	var skip_multiplier: int = current_stage_config.get("data_skip_multiplier", 1)
	current_wave += skip_multiplier
	
	# Check for software upgrade triggers at waves 20, 40, 60, 80
	_check_software_upgrade_triggers()
	
	if current_wave >= 100:
		_handle_victory()
	else:
		wave_changed.emit(current_wave)

func _check_software_upgrade_triggers() -> void:
	# Software upgrade triggers at waves 20, 40, 60, 80
	var upgrade_waves = [20, 40, 60, 80]
	for wave in upgrade_waves:
		if current_wave == wave:
			# Pause battle and show software upgrade overlay
			pause_battle()
			_show_software_upgrade_overlay()
			break

func _show_software_upgrade_overlay() -> void:
	var overlay_scene = load("res://scenes/overlays/software_upgrade_overlay.tscn")
	if overlay_scene:
		var overlay = overlay_scene.instantiate()
		overlay.upgrade_selected.connect(_on_software_upgrade_selected)
		overlay.re_roll_requested.connect(_on_software_upgrade_reroll)
		get_tree().current_scene.add_child(overlay)

func _on_software_upgrade_selected(upgrade_type: String, value: float) -> void:
	# Apply upgrade to mecha/weapon system
	print("Software upgrade selected: %s with value %.2f" % [upgrade_type, value])
	
	# Apply upgrade effects based on type
	match upgrade_type:
		"attack_speed":
			# Apply attack speed boost
			pass
		"missile_cooldown":
			# Apply missile cooldown reduction
			pass
		"bullet_velocity":
			# Apply bullet velocity boost
			pass
		"damage_boost":
			# Apply damage boost
			pass
		"overclock":
			# Apply overclock (double DPS for 5 waves)
			pass
	
	# Resume battle
	resume_battle()

func _on_software_upgrade_reroll() -> void:
	# Reroll logic handled by overlay
	print("Software upgrade options re-rolled")

func _on_stage_timer_timeout() -> void:
	if battle_state != BattleState.ACTIVE:
		return
	
	stage_time_remaining -= 1.0
	stage_time_changed.emit(stage_time_remaining)
	
	if stage_time_remaining <= 0:
		_handle_defeat("Stage time limit exceeded")

func _handle_defeat(reason: String) -> void:
	_set_battle_state(BattleState.DEFEATED)
	_stage_timer.stop()
	_spawn_timer.stop()
	
	# Evaluate if hitting the wall triggered a free robot claim
	var progression = get_node_or_null("/root/ProgressionManager")
	if progression:
		var stage_idx = progression.current_player_stage
		var checks = progression.evaluate_mecha_unlock_milestones(stage_idx)
		
		if not checks.is_empty():
			var unlocked_bot = checks[0]
			# Automatically equip the catch-up mecha to immediately clear the wall
			progression.set_active_mecha(unlocked_bot["mecha_id"])
			print("ALERT: Unlocked free catch-up mecha: ", unlocked_bot["name"])
	
	battle_defeat.emit(reason)

func _handle_victory() -> void:
	_set_battle_state(BattleState.VICTORY)
	_stage_timer.stop()
	_spawn_timer.stop()
	var progression = get_node_or_null("/root/ProgressionManager")
	if progression:
		progression.advance_stage()
	battle_victory.emit()

func pause_battle() -> void:
	if battle_state == BattleState.ACTIVE:
		_set_battle_state(BattleState.PAUSED)
		_stage_timer.stop()
		_spawn_timer.stop()

func resume_battle() -> void:
	if battle_state == BattleState.PAUSED:
		_set_battle_state(BattleState.ACTIVE)
		_stage_timer.start()
		_start_spawn_loop()

func _set_battle_state(new_state: BattleState) -> void:
	battle_state = new_state
	battle_state_changed.emit(new_state)

## Register enemy destruction (called by enemies)
func register_enemy_destruction() -> void:
	alive_enemy_count -= 1
	enemy_count_changed.emit(alive_enemy_count)
