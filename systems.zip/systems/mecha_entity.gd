extends Node2D
class_name MechaEntity

# --- SIGNALS ---
signal missile_fired(target: Node2D, damage: float)
signal stats_updated()

# --- VARIABLES ---
var base_attack_damage: float = 10.0
var base_attack_speed: float = 2.5 # attacks per second
var missile_damage: float = 10.0
var missile_max_targets: int = 5
var missile_cooldown: float = 10.0 # seconds

var current_mecha_id: String = "mecha_unit_alpha_base"
var progression_manager = null
var weapon_system = null

# --- HOMING MISSILE SKILL ---
var missile_timer: Timer
var missile_cooldown_remaining: float = 0.0

func _ready() -> void:
	progression_manager = get_node_or_null("/root/ProgressionManager")
	
	# Setup missile cooldown timer
	missile_timer = Timer.new()
	missile_timer.wait_time = missile_cooldown
	missile_timer.timeout.connect(_on_missile_cooldown_complete)
	add_child(missile_timer)
	
	_load_mecha_stats()
	_center_position()

func _center_position() -> void:
	var viewport = get_viewport()
	var viewport_size = viewport.get_visible_rect().size
	global_position = Vector2(viewport_size.x / 2.0, viewport_size.y / 2.0)

func _load_mecha_stats() -> void:
	if progression_manager:
		var mecha_stats = progression_manager.get_active_mecha_stats()
		if not mecha_stats.is_empty():
			current_mecha_id = mecha_stats.get("mecha_id", "mecha_unit_alpha_base")
			var base_stats = mecha_stats.get("base_stats", {})
			base_attack_damage = base_stats.get("attack_damage", 10.0)
			base_attack_speed = base_stats.get("attack_speed", 2.5)
			
			var skill = mecha_stats.get("skill", {})
			missile_damage = skill.get("total_damage", 50.0)
			missile_cooldown = skill.get("cooldown", 10.0)
			missile_max_targets = int(missile_damage / missile_damage) # Calculate rocket count
	
	# Apply upgrade modifiers
	_apply_upgrade_modifiers()
	
	# Update weapon system if connected
	if weapon_system:
		weapon_system.set_base_damage(base_attack_damage)
		weapon_system.set_attack_speed(base_attack_speed)
	
	stats_updated.emit()

func _apply_upgrade_modifiers() -> void:
	# Chassis Calibrator: attack speed 2.5 → 8.0
	var chassis_level = SaveSystem.get_upgrade_level("ballistic_core", "chassis_calibrator_level")
	if chassis_level > 0:
		base_attack_speed = lerp(2.5, 8.0, float(chassis_level) / 10.0)
	
	# Processor Overclock: missile cooldown 10.0 → 4.0
	var overclock_level = SaveSystem.get_upgrade_level("energy_matrix", "processor_overclock_level")
	if overclock_level > 0:
		missile_cooldown = lerp(10.0, 4.0, float(overclock_level) / 10.0)
	
	# Payload Expansion: rockets 5 → 15
	var payload_level = SaveSystem.get_upgrade_level("energy_matrix", "payload_expansion_level")
	if payload_level > 0:
		missile_max_targets = lerp(5, 15, float(payload_level) / 10.0)
	
	# Update missile timer
	if missile_timer:
		missile_timer.wait_time = missile_cooldown

func start_missile_cooldown() -> void:
	missile_cooldown_remaining = missile_cooldown
	missile_timer.start()

func _on_missile_cooldown_complete() -> void:
	_fire_homing_missiles()

func _fire_homing_missiles() -> void:
	var enemies = get_tree().get_nodes_in_group("enemies")
	if enemies.is_empty():
		return
	
	# Sort enemies by proximity
	enemies.sort_custom(func(a, b): 
		return global_position.distance_to(a.global_position) < global_position.distance_to(b.global_position)
	)
	
	# Fire missiles at up to max_targets
	var targets_to_fire = min(enemies.size(), missile_max_targets)
	for i in range(targets_to_fire):
		var target = enemies[i]
		if is_instance_valid(target):
			# Apply damage immediately (100% hit rate)
			if target.has_method("take_damage"):
				target.take_damage(missile_damage)
			
			missile_fired.emit(target, missile_damage)
	
	# Restart cooldown
	start_missile_cooldown()

func set_weapon_system(ws: WeaponSystem) -> void:
	weapon_system = ws
	if weapon_system:
		weapon_system.set_base_damage(base_attack_damage)
		weapon_system.set_attack_speed(base_attack_speed)

func _process(delta: float) -> void:
	# Update cooldown display
	if missile_timer and not missile_timer.is_stopped():
		missile_cooldown_remaining = missile_timer.time_left

func get_missile_cooldown_percent() -> float:
	if missile_cooldown <= 0:
		return 1.0
	return 1.0 - (missile_cooldown_remaining / missile_cooldown)
