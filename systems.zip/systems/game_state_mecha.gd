extends Node
class_name GameState

# --- SIGNALS ---
signal screen_changed(new_screen: Screen)
signal battle_state_changed(new_state: BattleState)

# --- ENUMS ---
enum Screen {
	BOOT,
	SPLASH,
	MAIN_MENU,
	BATTLE,
	SHOP,
	HANGAR,
	UPGRADES,
	BATTLE_PASS,
	LEADERBOARD,
	SETTINGS
}

enum BattleState {
	IDLE,
	ACTIVE,
	PAUSED,
	DEFEATED,
	VICTORY
}

# --- VARIABLES ---
var current_screen: Screen = Screen.BOOT
var is_battle_active: bool = false
var is_paused: bool = false

func go_to(screen: Screen) -> void:
	current_screen = screen
	screen_changed.emit(screen)

func get_current_screen() -> Screen:
	return current_screen

func set_battle_active(active: bool) -> void:
	is_battle_active = active
	if active:
		go_to(Screen.BATTLE)

func set_paused(paused: bool) -> void:
	is_paused = paused
	battle_state_changed.emit(BattleState.PAUSED if paused else BattleState.ACTIVE)
