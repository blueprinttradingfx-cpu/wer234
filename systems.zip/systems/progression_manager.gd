extends Node

# --- SIGNALS ---
signal stage_completed(stage_id: int)
signal mecha_unlocked(mecha_id: String)
signal active_mecha_changed(mecha_id: String)

# --- CONSTANTS ---
const CURRENT_VERSION := 1

# --- VARIABLES ---
var current_player_stage: int = 1
var unlocked_mecha_ids: Array[String] = ["mecha_unit_alpha_base"]
var active_mecha_id: String = "mecha_unit_alpha_base"

# --- CACHED DATABASES ---
var stage_db: Dictionary = {}
var robot_db: Dictionary = {}

func _ready() -> void:
	load_databases()

func load_databases() -> void:
	stage_db = _parse_json_file("res://data/stage_progression_matrix.json")
	robot_db = _parse_json_file("res://data/robot_unlock_catalog.json")
	print("Progression Databases initialized successfully.")

func _parse_json_file(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_error("Missing critical design database file at: " + path)
		return {}
	var file = FileAccess.open(path, FileAccess.READ)
	var content = file.get_as_text()
	file.close()
	var json = JSON.new()
	if json.parse(content) == OK:
		return json.data
	return {}

## Fetches the scaling variables for a specific stage, calculating the cycle multiplier
func get_config_for_stage(stage_num: int) -> Dictionary:
	var result = {
		"stage_name": "Unknown Grid Sector",
		"archetype": "The Entry Stream",
		"enemy_hp": 10.0, # Baseline
		"boss_hp": 290.0,
		"enemies_per_wave": 10,
		"velocity_modifier": 1.0,
		"data_skip_multiplier": 1
	}
	
	if stage_db.is_empty() or not stage_db.has("cycles"):
		return result
		
	for cycle in stage_db["cycles"]:
		if stage_num >= cycle["stage_range"][0] and stage_num <= cycle["stage_range"][1]:
			var hp_multiplier: float = cycle["enemy_base_hp_multiplier"]
			
			# Search for individual stage overrides inside the active cycle
			for stage in cycle["stages"]:
				if stage["stage_id"] == stage_num:
					result["stage_name"] = stage["stage_name"]
					result["archetype"] = stage["archetype"]
					result["enemy_hp"] = 10.0 * hp_multiplier # Applies the cycle stat wall
					result["boss_hp"] = stage["boss_hp"]
					result["enemies_per_wave"] = stage["enemies_per_wave"]
					result["velocity_modifier"] = stage["velocity_modifier"]
					result["data_skip_multiplier"] = stage["data_skip_multiplier"]
					break
			return result
	return result

## Checks milestones to evaluate if a free catching mecha should unlock
func evaluate_mecha_unlock_milestones(stage_attempted: int) -> Array:
	var newly_unlocked: Array = []
	if robot_db.is_empty() or not robot_db.has("mechas"):
		return newly_unlocked
		
	for mecha in robot_db["mechas"]:
		var mid: String = mecha["mecha_id"]
		if mid in unlocked_mecha_ids:
			continue
			
		var req = mecha["unlock_requirement"]
		if req["type"] == "stage_failed_or_reached" and stage_attempted >= req["value"]:
			unlocked_mecha_ids.append(mid)
			newly_unlocked.append(mecha)
			mecha_unlocked.emit(mid)
			
	return newly_unlocked

## Returns the dictionary data layout for the player's active mecha model
func get_active_mecha_stats() -> Dictionary:
	for mecha in robot_db["mechas"]:
		if mecha["mecha_id"] == active_mecha_id:
			return mecha
	return {}

## Returns all available mechas from robot catalog
func get_available_mechas() -> Array:
	if robot_db.is_empty() or not robot_db.has("mechas"):
		return []
	return robot_db["mechas"]

## Returns the current active mecha ID
func get_active_mecha_id() -> String:
	return active_mecha_id

## Checks if a mecha is unlocked
func is_mecha_unlocked(mecha_id: String) -> bool:
	return mecha_id in unlocked_mecha_ids

## Sets the active mecha and emits signal
func set_active_mecha(mecha_id: String) -> void:
	if mecha_id in unlocked_mecha_ids:
		active_mecha_id = mecha_id
		active_mecha_changed.emit(mecha_id)
	else:
		push_warning("Cannot set active mecha: %s not unlocked" % mecha_id)

## Advances the player to the next stage
func advance_stage() -> void:
	current_player_stage += 1
	stage_completed.emit(current_player_stage)

## Resets progression to stage 1
func reset_progression() -> void:
	current_player_stage = 1
